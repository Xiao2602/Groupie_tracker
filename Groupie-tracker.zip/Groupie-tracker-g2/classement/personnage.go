package rickEtMorty

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
)

// Structure de données représentant un personnage
type Personnage struct {
	ID      int    `json:"id"`      // récupère id
	Name    string `json:"name"`    // récupère nom
	Status  string `json:"status"`  // récupère alive ou dead
	Species string `json:"species"` // récupère la race
	Gender  string `json:"gender"`  // récupère le genre
	Origin  struct {
		Name string `json:"name"` //récupère earth, Abadango ou unknown
	} `json:"origin"`
	Location struct {
		Name string `json:"name"` // récupère citadel of ricks, unknown, Worldender's lair, interdimensional Cable, Abadango, Testicle Monster Dimension, Anatomy Park ou Earth (Replacement Dimension)
	} `json:"location"`
	Image string `json:"image"` // récupère l'image du personnage
}

// Fonction pour récupérer les données de l'API
func API() ([]Personnage, error) { // transforme les données en tableau de la structure personnage
	resp, err := http.Get("https://rickandmortyapi.com/api/character/") //envoie une requête à l'API
	if err != nil {
		return nil, fmt.Errorf("erreur lors de la récupération des données de l'API: %v", err)
	}
	defer resp.Body.Close() // utilisé pour éviter de dépasser la limite de connexion et augmenter la mémoire occupée

	// Lire le corps de la réponse dans un tableau de bytes
	body, err := ioutil.ReadAll(resp.Body) // resp.Body est un flux de donnée et ioutil.ReadAll lit tout le contenu pour stocker en mémoire dans la variable body
	if err != nil {
		return nil, fmt.Errorf("erreur lors de la lecture du corps de la réponse: %v", err) // %v s'adapte au type de variable qui suit
	}

	// Définir une structure pour recevoir les résultats de l'API
	var maitre struct {
		Results []Personnage `json:"results"` // results qui contient les informations de la structure
	}

	// Utiliser json.Unmarshal pour décoder les données JSON
	if err := json.Unmarshal(body, &maitre); err != nil {
		return nil, fmt.Errorf("erreur lors de la décodification des données: %v", err) //message erreur
	}

	return maitre.Results, nil
}
