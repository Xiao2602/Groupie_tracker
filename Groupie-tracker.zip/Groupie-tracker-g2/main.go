package main

import (
	"fmt"
	"html/template"
	"log"
	"net/http"
	rickEtMorty "rickEtMorty/classement" // Import du package rickEtMorty
)

// Fonction pour traiter la page d'accueil
func indexHandler(w http.ResponseWriter, r *http.Request) {
	tmpl, err := template.ParseFiles("templates/index.html")
	if err != nil {
		http.Error(w, "Erreur lors du chargement du template", http.StatusInternalServerError)
		return
	}
	tmpl.Execute(w, nil)
}

// Fonction pour afficher les personnages
func PersonnagesHandler(w http.ResponseWriter, r *http.Request) {
	// Récupération des personnages dans le package rickEtMorty (func API () )
	personnagesData, err := rickEtMorty.API()
	if err != nil {
		http.Error(w, "Erreur lors de la récupération des personnages", http.StatusInternalServerError)
		return
	}

	// Limiter à 20 personnages
	if len(personnagesData) > 20 {
		personnagesData = personnagesData[:20]
	}

	// Données à envoyer au template
	data := struct {
		Personnages []rickEtMorty.Personnage
	}{
		Personnages: personnagesData,
	}

	// Charger et exécuter le template
	tmpl, err := template.ParseFiles("templates/personnages.html")
	if err != nil {
		http.Error(w, "Erreur lors du chargement du template", http.StatusInternalServerError)
		return
	}

	tmpl.Execute(w, data)
}

func main() {
	// Charger les données de l'API au démarrage
	rickEtMorty.API()

	// Démarrer le serveur HTTP
	http.HandleFunc("/", indexHandler)                  // Page d'index
	http.HandleFunc("/personnages", PersonnagesHandler) // Page de personnages

	// Servir les fichiers statiques (CSS, images, etc.)
	http.Handle("/static/", http.StripPrefix("/static/", http.FileServer(http.Dir("static"))))

	fmt.Println("Serveur démarré. Cliquez sur http://localhost:8080")
	// Démarrer le serveur HTTP
	log.Fatal(http.ListenAndServe(":8080", nil))
}
