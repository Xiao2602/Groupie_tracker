document.addEventListener("DOMContentLoaded", () => {
  // Requête vers l'API Rick & Morty
  fetch("https://rickandmortyapi.com/api/character/")
    .then(response => response.json())
    .then(data => {
      const characters = data.results;
      const container = document.getElementById("characterList");

      // Créer un modal global réutilisable
      const modal = document.createElement("div");
      modal.id = "characterModal";
      modal.style.position = "fixed";
      modal.style.top = "50%";
      modal.style.left = "50%";
      modal.style.transform = "translate(-50%, -50%)";
      modal.style.backgroundColor = "white";
      modal.style.padding = "20px";
      modal.style.boxShadow = "0 0 10px rgba(0,0,0,0.5)";
      modal.style.borderRadius = "7px";
      modal.style.zIndex = 1000;
      modal.style.display = "none"; // Cacher au départ
      document.body.appendChild(modal);

      characters.forEach(char => {
        const card = document.createElement("div");
        card.className = "character-card";
        card.innerHTML = `
          <img src="${char.image}" width="150" height="150" alt="${char.name}">
          <h2>${char.name}</h2>
          <p><strong>Status:</strong> ${char.status}</p>
          <p><strong>Espèce:</strong> ${char.species}</p>
          <p><strong>Origine:</strong> ${char.origin.name}</p>
          <p><strong>Localisation:</strong> ${char.location.name}</p>
        `;

        // Au clic sur l'image, afficher/mettre à jour le modal
        card.querySelector("img").addEventListener("click", () => {
          modal.innerHTML = `
            <h2>${char.name}</h2>
            <p><strong>Status:</strong> ${char.status}</p>
            <p><strong>Espèce:</strong> ${char.species}</p>
            <p><strong>Origine:</strong> ${char.origin.name}</p>
            <p><strong>Localisation:</strong> ${char.location.name}</p>
            <button id="closeModal">Fermer</button>
          `;
          modal.style.display = "block";

          document.getElementById("closeModal").addEventListener("click", () => {
            modal.style.display = "none";
          });
        });

        container.appendChild(card);
      });
    })
    .catch(error => {
      console.error("Erreur lors du chargement des personnages :", error);
      document.getElementById("characterList").innerHTML = "<p>Impossible de charger les personnages.</p>";
    });
});

// Animation de bulles
function createBubble() {
  const bubble = document.createElement("div");
  bubble.classList.add("bubble");

  const size = Math.random() * 40 + 10;
  bubble.style.width = size + "px";
  bubble.style.height = size + "px";
  bubble.style.left = Math.random() * 100 + "vw";
  bubble.style.animationDuration = Math.random() * 5 + 5 + "s";
  bubble.style.opacity = Math.random() * 0.5 + 0.3;

  document.getElementById("background-animation").appendChild(bubble);
  setTimeout(() => bubble.remove(), 10000);
}

setInterval(() => {
  for (let i = 0; i < 3; i++) {
    createBubble();
  }
}, 200);
