const colors = [
  'radial-gradient(circle at 30% 30%, #39ff14, #0d4d00)',  // vert Rick & Morty
  'radial-gradient(circle at 50% 50%, #ffcc00, #996600)',  // jaune / or
  'radial-gradient(circle at 40% 40%, #00e5ff, #004d66)',  // bleu cyan
  'radial-gradient(circle at 60% 60%, #ff5c8d, #991f33)',  // rose vif
];

function createPlanet() {
  const planet = document.createElement('div');
  planet.classList.add('planet');

  const size = Math.random() * 80 + 50; // taille entre 50 et 130 px
  planet.style.width = size + 'px';
  planet.style.height = size + 'px';

  // Position aléatoire (pour que planète ne sorte pas)
  planet.style.top = Math.random() * (window.innerHeight - size) + 'px';
  planet.style.left = Math.random() * (window.innerWidth - size) + 'px';

  // Choix couleur dégradé aléatoire
  planet.style.background = colors[Math.floor(Math.random() * colors.length)];

  // Animation flottante durée 6-12 sec, alternée pour pas que toutes bougent en même temps
  planet.style.animationDuration = (Math.random() * 6 + 6) + 's';
  planet.style.animationDirection = Math.random() > 0.5 ? 'alternate' : 'alternate-reverse';

  // Ajouter un anneau pour certaines planètes (~50%)
  if (Math.random() > 0.5) {
    const ring = document.createElement('div');
    ring.classList.add('ring');
    ring.style.width = size * 1.6 + 'px';
    ring.style.height = size * 1.6 + 'px';
    planet.appendChild(ring);
  }

  document.getElementById('planet-background').appendChild(planet);

  // Nettoyer la planète après 30s pour pas surcharger
  setTimeout(() => planet.remove(), 30000);
}

// Générer 10 planètes au départ
for (let i = 0; i < 10; i++) {
  createPlanet();
}

// Ajouter une planète toutes les 3 secondes
setInterval(createPlanet, 3000);

//Commentaire pour le poster
document.addEventListener("DOMContentLoaded", () => {
  const formDiv = document.querySelector(".commentaires-form");
  const nameInput = formDiv.querySelector('input[type="text"]');
  const emailInput = formDiv.querySelector('input[type="email"]');
  const messageInput = formDiv.querySelector('textarea');
  const submitButton = formDiv.querySelector('button[type="submit"]');

  // Créer un conteneur pour afficher les commentaires sous le formulaire
  const commentsContainer = document.createElement("div");
  commentsContainer.id = "commentsContainer";
  commentsContainer.style.marginTop = "20px";
  formDiv.parentNode.insertBefore(commentsContainer, formDiv.nextSibling);

  submitButton.addEventListener("click", (e) => {
    e.preventDefault();

    const name = nameInput.value.trim();
    const email = emailInput.value.trim();
    const message = messageInput.value.trim();

    // Vérifications simples
    if (!name || !email || !message) {
      alert("Veuillez remplir tous les champs avant d'envoyer votre commentaire.");
      return;
    }

    // Créer un nouveau commentaire
    const comment = document.createElement("div");
    comment.style.border = "1px solid #007926";
    comment.style.backgroundColor = "#e0ffe0";
    comment.style.padding = "10px";
    comment.style.marginBottom = "10px";
    comment.style.borderRadius = "8px";
    comment.style.boxShadow = "0 2px 5px rgba(0, 0, 0, 0.1)";

    comment.innerHTML = `
      <p><strong>${sanitizeHTML(name)}</strong> dit :</p>
      <p>${sanitizeHTML(message)}</p>
    `;

    commentsContainer.appendChild(comment);

    // Réinitialiser le formulaire
    nameInput.value = "";
    emailInput.value = "";
    messageInput.value = "";
  });

  // Petite fonction pour éviter l'injection HTML (sécurité basique)
  function sanitizeHTML(str) {
    const temp = document.createElement("div");
    temp.textContent = str;
    return temp.innerHTML; //empêche des utilisateurs malveillants de "casser" ou pirater ta page avec du code HTML ou JS injecté dans un champ commentaire.
  }
});